<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Home - CRUD</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body class="container">
	<?php include 'menu.php'; ?>
	
	<h1> Página inicial </h1>


	
</body>
</html>