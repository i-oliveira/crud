<?php
define('SERVER', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DB', 'bd_agenda');

$conn = mysqli_connect(SERVER, USER, PASSWORD, DB);

?>
