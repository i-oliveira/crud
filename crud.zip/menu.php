
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<ul class="navbar-nav">
  <li class="nav-item">
    <a class="navbar-brand" href="index.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="cadastrar.php">Cadastrar</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="exibir.php">Exibir Cadastro</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="gerenciar.php">Excluir ou Editar Cadastro</a>
  </li>
</ul>
</nav>
